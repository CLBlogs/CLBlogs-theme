<!DOCTYPE html>
<html>
<head>
    <title>注册成功</title>
    <meta name="content-type";
          charset="UTF-8">
</head>
<body>
<div>
    <h1>注册成功！</h1>

    <br/> <a href="login.php">请重新登录</a>
</div>
</body>
</html>

